console.log("name: abc");
console.log("class: TE");
console.log("subject: WAD");
console.log("Docker Practical Running");